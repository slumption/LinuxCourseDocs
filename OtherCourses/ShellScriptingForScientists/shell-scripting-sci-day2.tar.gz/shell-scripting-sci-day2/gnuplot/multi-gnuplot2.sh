#!/bin/bash

# Run gnuplot program once for each output file
for zzFILES in zombie-*.dat
do
	# Copy output file to zombie.dat
	cp -f "${zzFILES}" zombie.dat

	# Run gnuplot
	gnuplot zombie.gplt

	# Delete zombie.dat file
	rm -f zombie.dat

	# Rename zombie.png
	mv zombie.png "${zzFILES}.png"
done
