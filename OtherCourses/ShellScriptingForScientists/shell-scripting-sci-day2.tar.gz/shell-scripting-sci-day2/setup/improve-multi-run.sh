#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/multi-run.sh scripts/multi-run.sh

echo "The multi-run.sh script in:"
echo "        $(pwd -P)/scripts"
echo "has been modified."
exit 0
