#!/bin/bash
# None of this is actually *needed* before we
#  modify multi-run.sh, so we run with set +e
set +e

# All paths are relative to the HOME directory
cd

echo "Ready for you to modify multi-run.sh."
exit 0
