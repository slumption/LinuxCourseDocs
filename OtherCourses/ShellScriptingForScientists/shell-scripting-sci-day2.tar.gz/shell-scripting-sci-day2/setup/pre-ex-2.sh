#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

# We don't mind if this copy doesn't succeed, so
#  we switch to running with set +e
set +e
cp -pf answers/run-once-using-read.sh scripts

# And now back to set -e
set -e 
cp -pf answers/run-while-read.sh scripts

echo "Ready for second exercise."
exit 0
