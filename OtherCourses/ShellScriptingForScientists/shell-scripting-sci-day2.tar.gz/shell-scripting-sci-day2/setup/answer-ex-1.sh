#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/first-exercise.sh scripts/multi-run.sh

echo "The answer to the first exercise is in the script:"
echo "        multi-run.sh"
echo "in:"
echo "        $(pwd -P)/scripts"
exit 0
