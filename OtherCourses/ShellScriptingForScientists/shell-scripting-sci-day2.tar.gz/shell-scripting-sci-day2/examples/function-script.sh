#!/bin/bash

function start()
{
	echo "${FUNCNAME}: Prepare to go!"
}

function do_something()
{
	echo "${FUNCNAME}: Doing stuff..."
	echo "Arguments: ${@}"
	echo "Doing more stuff..."
}

function end()
{
	echo "${FUNCNAME}: and now we end..."
}

function main()
{
	start
	do_something "${@}"
	end
}

main "${@}"
