#!/bin/bash

# Parameters that stay the same each run
myFIXED_PARAMS="0.005 0.0175 0.01 0.01"

# Run zombie.py program once for each argument
#  Note: *no* quotes around ${myFIXED_PARAMS}
#        or they'll be interpreted as one argument!
for zzARGS in "${@}" ; do
	"${HOME}/scripts/run-once.sh" ${myFIXED_PARAMS} "${zzARGS}"
done
