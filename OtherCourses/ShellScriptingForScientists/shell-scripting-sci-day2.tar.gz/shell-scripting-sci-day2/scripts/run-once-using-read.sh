#!/bin/bash

# Read in parameters from standard input
read -p "Input parameters for zombie.py: " myZD myI myR myD mySIZE

# Remove left over running-zombie file
rm -f running-zombie

# Write to logfile
echo "" >> logfile
date >> logfile
echo "Running zombie.py with ${myZD} ${myI} ${myR} ${myD} ${mySIZE}" >> logfile

# Run zombie.py with passed arguments
ZOMBIE_FORMAT="NORMAL" ./zombie.py "${myZD}" "${myI}" "${myR}" "${myD}" "${mySIZE}" > "stdout-${mySIZE}"

# Rename output file
mv zombie.dat "zombie-${mySIZE}.dat"

# Remove left over running-zombie file
rm -f running-zombie

# Write to logfile
echo "Output file: zombie-${mySIZE}.dat" >> logfile
echo "Standard output: stdout-${mySIZE}" >> logfile
