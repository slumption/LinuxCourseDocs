#!/bin/bash
function hello()
{
	# This is a shell function.
	echo "Hello, ${1}"
	echo "I am function ${FUNCNAME}."
}

#echo "First argument: ${1}"
hello "${1}"
