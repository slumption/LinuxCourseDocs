#!/bin/bash

function run_program()
{
# This function runs the zombie.py program

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "" >> logfile
	date >> logfile
	echo "Running zombie.py with ${@}" >> logfile

	# Run zombie.py with passed arguments
	ZOMBIE_FORMAT="NORMAL" ./zombie.py "${@}" > "stdout-${5}"

	# Rename output file
	mv zombie.dat "zombie-${5}.dat"

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "Output file: zombie-${5}.dat" >> logfile
	echo "Standard output: stdout-${5}" >> logfile
}

# Parameters that stay the same each run
myFIXED_PARAMS="0.005 0.0175 0.01 0.01"

# Run zombie.py program once for each argument
#  Note: *no* quotes around ${myFIXED_PARAMS}
#        or they'll be interpreted as one argument!
for zzARGS in "${@}" ; do
	run_program ${myFIXED_PARAMS} "${zzARGS}"
done
