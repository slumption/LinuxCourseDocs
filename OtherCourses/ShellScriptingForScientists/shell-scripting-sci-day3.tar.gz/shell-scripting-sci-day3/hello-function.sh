#!/bin/bash
function hello()
{
	# This is a shell function.
	echo "Hello."
	echo "I am function ${FUNCNAME}."
}

