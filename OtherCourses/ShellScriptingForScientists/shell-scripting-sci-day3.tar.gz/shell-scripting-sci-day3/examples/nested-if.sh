#!/bin/bash
set -e

function first_function()
{
	echo "You picked option one:"
	echo "A kitten!"
	return 0
}

function second_function()
{
	echo "You picked option two:"
	echo "Phone a friend"
	return 0
}

function third_function()
{
	echo "You picked option three:"
	echo "A year's free supply of kitten paraphenalia!"
	return 0
}

function fourth_function()
{
	echo "You picked option four:"
	echo "What's wrong with option one?"
	echo "Don't you *like* cats!?!?"
	return 0
}


if [ "${1}" = "one" ] ; then
	first_function
elif [ "${1}" = "two" ] ; then
	second_function
elif [ "${1}" = "three" ] ; then
	third_function
elif [ "${1}" = "four" ] ; then
	fourth_function
else
	echo "Huh?" >&2
	exit 1
fi
