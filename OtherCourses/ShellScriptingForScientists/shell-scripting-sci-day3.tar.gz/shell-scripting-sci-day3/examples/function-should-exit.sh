#!/bin/bash
set -e

function fail()
{
	# This function should always cause the script
	#  to exit with a non-zero exit status
	echo "In function ${FUNCNAME}."
	set -e
	false
	echo "You should never see this message."
}

echo "About to run function fail."
if fail ; then
	echo "Woo-hoo!  Function fail succeeded."
else
	echo "Nooooo!  Function fail didn't work."
fi
