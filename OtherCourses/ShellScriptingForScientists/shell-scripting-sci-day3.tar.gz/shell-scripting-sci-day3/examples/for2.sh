#!/bin/bash
set -e

# Examples of for loops

echo "First for loop:"
myCOLOURS="red green blue magenta"
for zzVALS in ${myCOLOURS} ; do
	echo "Colour: ${zzVALS}"
done

echo ""
echo "Second for loop (probably not what we wanted!):"
myCOLOURS="red green blue magenta"
for zzVALS in "${myCOLOURS}" ; do
	echo "Colour: ${zzVALS}"
done

echo ""
echo "for loop over files:"
for zzFILES in * ; do
	ls -l "${zzFILES}"
done
