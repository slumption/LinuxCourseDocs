#!/bin/bash
set -e

# Examples of for loop

myCOLOURS="red green blue"

for zzVAR in ${myCOLOURS} ; do

	echo "${zzVAR}"

done

echo "End."
