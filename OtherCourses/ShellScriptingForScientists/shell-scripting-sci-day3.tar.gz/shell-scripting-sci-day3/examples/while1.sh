#!/bin/bash
set -e

# Example of a while loop to read a line of a file at a time
zzLINE="1"
while read myINP ; do
	echo "${zzLINE}: ${myINP}"
	zzLINE="$(( ${zzLINE} + 1 ))"
done < "hello-function.sh"
