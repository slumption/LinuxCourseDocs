#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/second-exercise.sh scripts/multi-sizes-errors.sh

echo "The answer to the second exercise is in the script:"
echo "        multi-sizes-errors.sh"
echo "in:"
echo "        $(pwd -P)/scripts"
exit 0
