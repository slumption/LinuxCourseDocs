#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/multi-sizes-before-exercise.sh scripts/multi-sizes.sh

echo "Ready for first exercise."
exit 0
