#!/bin/bash

myINFECTS="0.0075 0.01 0.0175 0.0185 0.0195"
myZD="0.005"
myR="0.01"
myD="0.01"

for zzINFS in ${myINFECTS} ; do
	zzSIZE="50"
	while [ "${zzSIZE}" -le "50000" ] ; do
		echo "${myZD} ${zzINFS} ${myR} ${myD} ${zzSIZE}" >> new_param_set
		zzSIZE="$(( ${zzSIZE} * 10 ))"
	done
done
