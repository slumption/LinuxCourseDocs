#!/bin/bash
set -e

function run_program()
{
# This function runs the zombie.py program

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "" >> "${myLOGFILE}"
	date >> "${myLOGFILE}"
	echo "Running ${myPROG} with ${@}" >> "${myLOGFILE}"

	# Run program with passed arguments
	"${myPROG}" "${@}" > "stdout-${1}-${2}-${3}-${4}-${5}"

	# Remove left over running-zombie file
	rm -f running-zombie

	# Run gnuplot
	gnuplot "${myGPLT_FILE}"

	# Rename files
	mv zombie.dat "zombie-${1}-${2}-${3}-${4}-${5}.dat"
	mv zombie.png "zombie-${1}-${2}-${3}-${4}-${5}.png"

	# Write to logfile
	echo "Output file: zombie-${1}-${2}-${3}-${4}-${5}.dat" >> "${myLOGFILE}"
	echo "Plot of output file: zombie-${1}-${2}-${3}-${4}-${5}.png" >> "${myLOGFILE}"
	echo "Standard output: stdout-${1}-${2}-${3}-${4}-${5}" >> "${myLOGFILE}"
}

# Program to run: zombie.py
myPROG="$(pwd -P)/zombie.py"

# Set up environment variables for program
export ZOMBIE_FORMAT="NORMAL"

# Location of gnuplot file
myGPLT_FILE="$(pwd -P)/zombie.gplt"

# My current directory
myDIR="$(pwd -P)"

# Location of log file
myLOGFILE="${myDIR}/logfile"

# Temporary directory for me to work in
myTEMP_DIR="$(mktemp -t -d zombie.XXXXXXXXX)"

# Change to temporary directory
cd "${myTEMP_DIR}"

# Read in parameters from standard input
#   and then run program with them
#   and run it again and again until there are no more
while read myZD myI myR myD mySIZE myJUNK ; do

	# Instead of using read in value for size,
	#  use 50, then 500, then 5000.
	zzSIZE=50
	while [ "${zzSIZE}" -le "5000" ]  ; do
	
		# Run program
		run_program "${myZD}" "${myI}" "${myR}" "${myD}" "${zzSIZE}"

		zzSIZE=$(( ${zzSIZE} * 10 ))
	done

done

# Copy files back to my directory
cp -fpR . "${myDIR}"

# Go back to my directory
cd "${myDIR}"

# Clean up
rm -Rf "${myTEMP_DIR}"
