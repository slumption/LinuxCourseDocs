#!/bin/bash

# Run gnuplot program once for each output file
for zzFILES in zombie-*.dat ; do

	# Rename output file to zombie.dat
	mv "${zzFILES}" zombie.dat

	# Run gnuplot
	gnuplot zombie.gplt

	# Rename zombie.dat to original name
	mv zombie.dat "${zzFILES}"

	# Rename zombie.png
	mv zombie.png "${zzFILES}.png"
done
