#!/usr/bin/python

# This code is based on the MATLAB code by Philip Munz (November 12, 2008)
# written to solve the system of ODE's for the basic model used in the 
# Zombie Dynamics project for MAT 5187, as provided in Chapter 4 
# (When Zombies Attack!: Mathematical Modelling of an Outbreak of Zombie
# Infection), pp. 133-150 of 
# Infectious Disease Modelling Research Progress, 2009
# Jean Michel Tchuenche & Christinah Chiyaka (eds.)
# Nova Science Publishers, Inc
# ISBN 978-1-60741-347-9

import sys, os
import os.path
import time


def solve_ODE(a,b,ze,d,T,dt,N):
	"""This function will solve the system of ODE's for the basic model used in
the Zombie Dynamics project for MAT 5187.
Function Inputs: a - alpha value in model: "zombie destruction" rate
                 b - beta value in model: "new zombie" rate
                 ze - zeta value in model: zombie resurrection rate
                 d - delta value in model: background death rate
                 T - Stopping time
                 dt - time step for numerical solutions
                 N - initial population in thousands

Function Outputs: t - list of time steps
                  s - list of susceptibles (humans) at each time step
                  z - list of zombies at each time step"""

	# Based on MATLAB code created by Philip Munz on November 12, 2008

	import math

	# Initial set up of solution vectors
	n = int(math.ceil(T/dt))
	t = [i*dt for i in range(0,n+1)]
	s = [0 for i in range(0,n+1)]
	z = [0 for i in range(0,n+1)]
	r = [0 for i in range(0,n+1)]
	del i

	s[0] = N
	z[0] = 0
	r[0] = 0

	# Define the ODE's of the model and solve numerically by Euler's method:
	for i in range(0,n):
		s[i+1] = s[i] + dt*(-b*s[i]*z[i])  # here we assume birth rate = background deathrate, so only term is -b term
    		z[i+1] = z[i] + dt*(b*s[i]*z[i] -a*s[i]*z[i] +ze*r[i])
		r[i+1] = r[i] + dt*(a*s[i]*z[i] +d*s[i] - ze*r[i])
		if s[i]<0 or s[i]>N:
			break
		if z[i]>N or z[i]<0:
			break
		if r[i]<0 or r[i]>N:
			break

	return (t,s,z)



if (len(sys.argv) < 6):
	sys.stderr.write('Wrong number of arguments!\n')
	sys.stderr.write('5 required, %d found.\n' % (len(sys.argv)-1))
	sys.stderr.write('Usage: %s zom_death infect resurrect death size\n' % str(sys.argv[0]))
	sys.exit(1)

#For reference: some sensible values
#alpha = 0.005
#beta = 0.0175
#zeta = 0.0001
#delta = 0.0001
#N0 = 500
#days = 10
#days = 5
#tstep = 0.001

alpha = float(sys.argv[1])
if alpha < 0.0:
	sys.stderr.write('zom_death (alpha) must not be negative\n')
	sys.exit(1)

beta = float(sys.argv[2])
if beta <= 0.0:
	sys.stderr.write('infect (beta) must be positive\n')
	sys.exit(1)

zeta = float(sys.argv[3])
if zeta <= 0.0:
	sys.stderr.write('resurrect (zeta) must be positive\n')
	sys.exit(1)

delta = float(sys.argv[4])
if delta < 0.0:
	sys.stderr.write('death (delta) must not be negative\n')
	sys.exit(1)

N0 = long(sys.argv[5])
if N0 <= 0L:
	sys.stderr.write('size must be positive\n')
	sys.exit(1)

if len(sys.argv) >= 7:
	days = float(sys.argv[6])
	if time <= 0.0:
		sys.stderr.write('time must be positive\n')
		sys.exit(1)
else:
	days = 10.0

if len(sys.argv) >= 8:
	tstep = float(sys.argv[7])
	if tstep <= 0.0:
		sys.stderr.write('timestep must be positive\n')
		sys.exit(1)
else:
	tstep = days/10000.0

SCI_FMT = True
if 'ZOMBIE_FORMAT' in os.environ:
	if os.environ['ZOMBIE_FORMAT'].upper() == 'NORMAL':
		SCI_FMT = False

if os.path.exists('running-zombie'):
	sys.stderr.write('Zombie Attack already running in this directory!\n')
	sys.exit(1)
else:
	running=open('running-zombie','w')
	running.close()
	del running


print '\nWhen Zombies Attack!: Basic Model of outbreak of zombie infection\n'

if SCI_FMT:
	print 'Population size:\t%.4e' % (N0 * 1000)
	print 'Model run time:\t\t%.1e days' % days
	print '\nZombie destruction rate (alpha):\t%e' % alpha
	print 'Zombie infection rate (beta):\t\t%e' % beta
	print 'Zombie resurrection rate (zeta):\t%e' % zeta
	print 'Natural death [and birth] rate (delta):\t%e' % delta
else:
	print 'Population size:\t%d' % (N0 * 1000)
	print 'Model run time:\t\t%.1f days' % days
	print '\nZombie destruction rate (alpha):\t%.4f' % alpha
	print 'Zombie infection rate (beta):\t\t%.4f' % beta
	print 'Zombie resurrection rate (zeta):\t%.4f' % zeta
	print 'Natural death [and birth] rate (delta):\t%.4f' % delta

start = time.time()

(T,S,Z) = solve_ODE(alpha,beta,zeta,delta,days,tstep,N0)

elapsed = time.time() - start

data=open('zombie.dat','w')
for i in range(0,len(T)):
	data.write('%f\t%f\t%f\n' % (T[i],S[i],Z[i]))
del i
data.close()
del data

print '\nOutput file:\t\tzombie.dat'

if SCI_FMT:
	print '\nModel took %e seconds' % elapsed
else:
	print '\nModel took %.3f seconds' % elapsed
