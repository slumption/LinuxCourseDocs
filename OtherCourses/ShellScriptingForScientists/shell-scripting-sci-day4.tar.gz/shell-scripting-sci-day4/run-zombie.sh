#!/bin/bash

# Remove left over running-zombie file
rm -f running-zombie

# Run zombie.py with arguments: 0.005 0.0175 0.01 0.01 50
./zombie.py 0.005 0.0175 0.01 0.01 50

# Rename output file
mv zombie.dat zombie-50.dat


# Remove left over running-zombie file
rm -f running-zombie

# Run zombie.py with arguments: 0.005 0.0175 0.01 0.01 500
./zombie.py 0.005 0.0175 0.01 0.01 500

# Rename output file
mv zombie.dat zombie-500.dat


# Remove left over running-zombie file
rm -f running-zombie

# Run zombie.py with arguments: 0.005 0.0175 0.01 0.01 5000
./zombie.py 0.005 0.0175 0.01 0.01 5000

# Rename output file
mv zombie.dat zombie-5000.dat


# Remove left over running-zombie file
rm -f running-zombie
