#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <sys/errno.h>
#include <math.h>
#include <sys/stat.h>
#include <time.h>

/*
  This program iterates the unit square under the iteration
  x' = x + y
  y' = y + y*epsilon*sin(2pi*x)
  with both calculations modulo 1.0.

  The system iterates a series of points whose initial positions form
  an nx by ny regular grid on the unit square.  Each point is iterated
  "n_iter" many times.

 */

int main
(
 int argc,
 char **argv
 )
{
  const char outfile_name[] = "output.dat";
  const char flagfile_name[] = "running";
  FILE *outfile;
  FILE *flagfile;
  struct stat flagfile_stat; /* Used to discard file information from stat() */

  double start_time, end_time;

  long nxl = 0L;
  long nyl = 0L;
  long n_iter = 0L;
  double epsilon = 0.0;

  const double twopi = 2.0*M_PI;

  long ix = 0L;
  long iy = 0L;
  double x = 0.0;
  double y = 0.0;
  double xx = 0.0;
  double yy = 0.0;
  long count = 0L;
  double junk = 0.0; /* Used to discard integer part in modf() */

  /* Process the user's command line arguments. */
  if (argc != 5)
    {
      fprintf(stderr, "Wrong number of arguments!\n4 expected, %d found.\nUsage: %s Nx Ny n_iterations epsilon\n", (argc-1), argv[0]);
      exit(1);
    }

  nxl = strtol(argv[1], NULL, 10);
  if (0 != errno)
    {
      perror("Invalid Nx: ");
      exit(1);
    }
  if (0L >= nxl)
    {
      fprintf(stderr, "Nx must be positive\n");
      exit(1);
    }

  nyl = strtol(argv[2], NULL, 10);
  if (0 != errno)
    {
      perror("Invalid Ny: ");
      exit(1);
    }
  if (0L >= nyl)
    {
      fprintf(stderr, "Ny must be positive\n");
      exit(1);
    }

  n_iter = strtol(argv[3], NULL, 10);
  if (0 != errno)
    {
      perror("Invalid n_iterations: ");
      exit(1);
    }
  if (0L >= n_iter)
    {
      fprintf(stderr, "n_iterations must be positive\n");
      exit(1);
    }

  epsilon = strtod(argv[4], NULL);
  if (0 != errno)
    {
      perror("Invalid epsilon: ");
      exit(1);
    }

  /* Check for existence of status file; if present abort */
  if ( 0 == stat(flagfile_name, &flagfile_stat))
    {
      fprintf(stderr, "Already running in this directory!\n");
      exit(1);
    }
  if (ENOENT != errno)
    {
      perror("Status file present? (means already running in this directory): ");
      exit(1);
    }

  /* Open output file */
  if (NULL == (outfile = fopen(outfile_name, "w")))
    {
      fprintf(stderr, "Cannot open output file %s: %s\n", outfile_name, strerror(errno));
      exit(1);
    }

  /* Open status file */
  if (NULL == (flagfile = fopen(flagfile_name, "w")))
    {
      fprintf(stderr, "Cannot open status file %s: %s\n", flagfile_name, strerror(errno));
      fclose(outfile);
      exit(1);
    }

  printf("x dimension of grid:\t%ld\n"
         "y dimension of grid:\t%ld\n"
         "Number of iterations:\t%ld\n"
         "Epsilon:\t\t%f\n"
         "\nOutput file:\t\t%s\n\n", nxl, nyl, n_iter, epsilon, outfile_name);
         /* This type of line continuation is a feature of ANSI C */

  /* Run */
  start_time = (double) clock();
  for (ix = 0L; ix < nxl; ix += 1L)
    {
      for (iy = 0L; iy < nyl; iy += 1L)
	{
	  x = ((double)ix)/((double)nxl);
	  y = ((double)iy)/((double)nyl);
	  for (count=0L; count < n_iter; count += 1L)
	    {
	      xx = modf(1.0 + x + y, &junk);
	      yy = modf(1.0 + y + epsilon*y*sin(twopi*x), &junk);
	      x = xx;
	      y = yy;
	    }
	  /* printf("%f\t%f\n", x, y); */
	  if (0 >= fprintf(outfile, "%f\t%f\n", x, y))
	    {
	      fprintf(stderr, "Error writing to output file %s: %s\n", outfile_name, strerror(errno));
	      fclose(outfile);
	      fclose(flagfile);
	      exit(1);
	    }
	}
    }
  end_time = (double) clock();
  /* printf("start time: %f\tend time: %f\n", start_time, end_time); */
  if ((-1 == start_time) || (-1 == end_time))
    {
      printf("Unable to time program...\n");
    }
  else
    {
      printf("Iterations took %.3f seconds\n", ((end_time - start_time) / CLOCKS_PER_SEC));
    }

  /* Close files */
  if (0 != (fclose(outfile)))
    {
      /* Since writing to a file is usually buffered, errors writing to 
         the file may not occur until we close the file, when the file 
         buffers are flushed. */
      fprintf(stderr, "Error writing to output file %s: %s\n", outfile_name, strerror(errno));
      fclose(flagfile);
      exit(1);
    }
  if (0 != (fclose(flagfile)))
    {
      fprintf(stderr, "Error closing status file %s: %s\n", flagfile_name, strerror(errno));
      exit(1);
    }

  /* All done! */  
  exit(0);
}
