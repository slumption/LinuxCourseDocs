#!/bin/bash

myPROGS="${HOME}/source"
myBACKUPS="${HOME}/backup"

# Make backup directory
mkdir -p "${myBACKUPS}"

# Move editor backups to backup directory
mv "${myPROGS}"/*~ "${myBACKUPS}"
mv "${myPROGS}"/*.bak "${myBACKUPS}"

# Delete compiler object files
rm -f "${myPROGS}"/*.o
