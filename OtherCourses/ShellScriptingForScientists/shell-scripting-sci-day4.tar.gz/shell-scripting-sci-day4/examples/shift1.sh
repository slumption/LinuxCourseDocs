#!/bin/bash
set -e

while [ "${#}" -gt "0" ] ; do

	echo "No. of arguments: ${#}"
	echo "Arguments: ${@}"
	echo "First argument is: ${1}"
	echo "" 

	shift

done

echo "No. of arguments: ${#}"
