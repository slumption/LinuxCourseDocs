#!/bin/bash
set -e

function hyphenated_args()
{
	local myOUTPUT zzARG_NO
	myOUTPUT="${1}"
	shift
	while [ "${#}" -gt "0" ] ; do
		myOUTPUT="${myOUTPUT}-${1}"
		shift
	done
	echo "${myOUTPUT}"
	return 0
}

myPARAMS="$(hyphenated_args ${@})"
echo "${myPARAMS}"
