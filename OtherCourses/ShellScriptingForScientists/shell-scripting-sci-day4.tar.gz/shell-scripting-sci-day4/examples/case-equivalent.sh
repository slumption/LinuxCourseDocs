#!/bin/bash
set -e

function first_function()
{
	echo "You picked option one:"
	echo "A kitten!"
	return 0
}

function second_function()
{
	echo "You picked option two:"
	echo "Phone a friend"
	return 0
}

function third_function()
{
	echo "You picked option three:"
	echo "A year's free supply of kitten paraphenalia!"
	return 0
}

function fourth_function()
{
	echo "You picked option four:"
	echo "What's wrong with option one?"
	echo "Don't you *like* cats!?!?"
	return 0
}


case "${1}" in
	"one")
		first_function
		;;
	"two")
		second_function
		;;
	"three")
		third_function
		;;
	"four")
		fourth_function
		;;
	*)
		echo "Huh?" >&2
		exit 1
esac
