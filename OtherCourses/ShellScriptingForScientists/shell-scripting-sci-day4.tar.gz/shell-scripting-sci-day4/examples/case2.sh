#!/bin/bash
set -e


case "${1}" in
	"1")
		echo "Running while1.sh"
		./while1.sh
		;;
	"2")
		echo "Running while2.sh"
		./while2.sh
		;;
	*)
		echo "Invalid input: ${1}"
		;;
esac

echo "End of ${0} script."
exit 0
