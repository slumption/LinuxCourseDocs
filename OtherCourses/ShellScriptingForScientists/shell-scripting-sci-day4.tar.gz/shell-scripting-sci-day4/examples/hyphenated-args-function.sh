#!/bin/bash -e

function hyphenated_args()
{
	local myOUTPUT zzARG_NO
	myOUTPUT="${1}"
	zzARG_NO="1"
	while [ "${zzARG_NO}" -lt "${#}" ] ; do
		zzARG_NO="$(( zzARG_NO + 1 ))"
		myOUTPUT="${myOUTPUT}-${!zzARG_NO}"
	done
	echo "${myOUTPUT}"
	return 0
}
