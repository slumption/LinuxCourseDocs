#!/bin/bash
set -e

function first_function()
{
	echo "You picked option one:"
	echo "A kitten!"
	return 0
}

function second_function()
{
	echo "You picked option two:"
	echo "Phone a friend"
	return 0
}

function third_function()
{
	echo "You picked option three:"
	echo "A year's free supply of kitten paraphenalia!"
	return 0
}

function fourth_function()
{
	echo "Hey, you didn't pick option one."
	echo "What's wrong with option one?"
	echo "Don't you *like* cats!?!?"
	return 0
}



case "${1}" in
	"1"|"one"|"ONE")
		first_function
		;;
	"2"|"two"|"TWO")
		second_function
		;;
	"3"|"three"|"THREE")
		third_function
		;;
	"4"|"four"|"FOUR"|"5"|"five"|"FIVE")
		fourth_function
		;;
	*)
		echo "Huh?" >&2
		exit 1
esac
