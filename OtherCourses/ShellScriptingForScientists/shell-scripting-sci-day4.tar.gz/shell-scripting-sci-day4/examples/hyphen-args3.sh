#!/bin/bash
set -e

source hyphenated-args-function.sh

myPARAMS="$(hyphenated_args ${@})"
echo "${myPARAMS}"
