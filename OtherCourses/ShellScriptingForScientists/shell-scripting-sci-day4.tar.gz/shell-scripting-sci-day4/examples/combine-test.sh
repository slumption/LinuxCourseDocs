#!/bin/bash
set -e

if [ -z "${1}" ] ; then
	myNUMBER=5431
else
	myNUMBER="${1}"
fi

# Say whether 0 < myNUMBER < 10000 using && (AND)
if [ "${myNUMBER}" -gt "0" ] &&
   [ "${myNUMBER}" -lt "10000" ] ; then
	echo "Number (${myNUMBER}) is in range."
else
	echo "Number (${myNUMBER}) is out of range." >&2
fi

# Say whether 0 < myNUMBER < 10000 using || (OR)
if [ "${myNUMBER}" -le "0" ] ||
   [ "${myNUMBER}" -ge "10000" ] ; then
	echo "Number (${myNUMBER}) is out of range." >&2
else
	echo "Number (${myNUMBER}) is in range."
fi
