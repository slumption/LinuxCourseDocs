#!/bin/bash
set -e

if [ "${#}" -eq "0" ] ; then

	echo "No arguments to process!" >&2
	exit 1

fi

myFILE="/etc/motd"
myDIR="${HOME}"
myDEBUG=0

while [ "${#}" -gt "0" ] ; do

	case "${1}" in
		"-h"|"--help")
			echo "This script processes command-line parameters"
			exit 0
			;;
		"-d")
			shift
			myDIR="${1}"
			if [ ! -d "${myDIR}" ] ; then
				echo "${myDIR} is not a directory"
				exit 1
			fi
			;;
		"-f")
			shift
			myFILE="${1}"
			if [ ! -e "${myFILE}" ] ; then
				echo "${myFILE} does not exist"
				exit 1
			fi
			;;
		"-v")
			echo "Debugging turned on"
			myDEBUG="1"
			;;
		*)
			echo "Option ${1} is not understood!"
			exit 1
			;;
	esac

	shift

done

if [ "${myDEBUG}" -eq "1" ] ; then

	set -x

fi

echo "myDIR: ${myDIR}"
echo "myFILE: ${myFILE}"
