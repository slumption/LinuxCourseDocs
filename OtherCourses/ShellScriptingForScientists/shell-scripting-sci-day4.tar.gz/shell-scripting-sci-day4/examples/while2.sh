#!/bin/bash
set -e

# Example of while loops to do something a given number of times

echo "First while loop - on entering loop counter is 1:"
zzCOUNT="1"
while [ "${zzCOUNT}" -le "6" ] ; do
	echo "${zzCOUNT}"
	zzCOUNT="$(( ${zzCOUNT} + 1 ))"
done

echo ""
echo "Second while loop - on entering loop counter is 0:"
zzCOUNT="0"
while [ "${zzCOUNT}" -le "6" ] ; do
	echo "${zzCOUNT}"
	zzCOUNT="$(( ${zzCOUNT} + 1 ))"
done
