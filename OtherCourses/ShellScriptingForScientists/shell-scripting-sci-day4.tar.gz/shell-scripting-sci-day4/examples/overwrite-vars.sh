#!/bin/bash
set -e

function trash_vars()
{
	myOUTPUT="rubbish"
	zzCOUNT="6"
	return 0
}

myOUTPUT="good"
zzCOUNT="1"

echo "Start counting..."
while [ "${zzCOUNT}" -le "6" ] ; do
	echo "${zzCOUNT}"
	trash_vars
	zzCOUNT="$(( zzCOUNT + 1 ))"
done

echo "myOUTPUT: ${myOUTPUT}"
