#!/bin/bash
function hello()
{
	echo "First argument in function: ${1}"
	echo "Second argument in function: ${2}"
	# This is a shell function.
	echo "Hello, ${1}"
	echo "I am function ${FUNCNAME}."
}

echo "First argument: ${1}"
echo "Second argument: ${2}"
hello "${2}" "${1}"
