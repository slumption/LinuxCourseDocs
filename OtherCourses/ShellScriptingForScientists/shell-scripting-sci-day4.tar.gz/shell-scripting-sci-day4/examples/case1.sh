#!/bin/bash
set -e

case "${1}" in
	"red"|"black")
		echo "I like ${1}"
		;;
	"gray"|"maroon"|"umber")
		echo "I don't like ${1}"
		;;
	"light green")
		echo "I have no strong feelings about ${1}"
		;;
	"")
		echo "Hey!  That's not a colour!"
		exit 1
		;;
	*)
		echo "Is ${1} a colour?"
		;;
esac
