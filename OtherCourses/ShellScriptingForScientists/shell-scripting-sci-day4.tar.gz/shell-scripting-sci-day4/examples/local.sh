#!/bin/bash
set -e

function safe_vars()
{
	local myOUTPUT
	myOUTPUT="function data"
	echo "In ${FUNCNAME}, myOUTPUT: ${myOUTPUT}"
	return 0
}

myOUTPUT="main data"
echo "myOUTPUT: ${myOUTPUT}"

echo "Calling safe_vars..."
safe_vars

echo "myOUTPUT: ${myOUTPUT}"
