#!/bin/bash
set -e

function hyphenated_args()
{
	myOUTPUT="${1}"
	zzARG_NO="1"
	while [ "${zzARG_NO}" -lt "${#}" ] ; do
		zzARG_NO="$(( zzARG_NO + 1 ))"
		myOUTPUT="${myOUTPUT}-${!zzARG_NO}"
	done
	return 0
}

hyphenated_args "${@}"
echo "${myOUTPUT}"
