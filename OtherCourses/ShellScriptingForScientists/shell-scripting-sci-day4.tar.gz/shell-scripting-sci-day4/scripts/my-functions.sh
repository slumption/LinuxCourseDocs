#!/bin/bash -e

function hyphenated_args()
{
	local myOUTPUT zzARG_NO

	myOUTPUT="${1}"
	zzARG_NO="1"

	while [ "${zzARG_NO}" -lt "${#}" ] ; do

		zzARG_NO="$(( zzARG_NO + 1 ))"

		myOUTPUT="${myOUTPUT}-${!zzARG_NO}"

	done

	echo "${myOUTPUT}"

	return 0
}


function rename_files()
{
# Function to rename files: it renames all files ending in the
#  first argument to files ending in the second argument.

	local zzFILE

	# If no first argument return with an error
	if [ -z "${1}" ] ; then
		return 1
	fi

	# If no second argument return with an error
	if [ -z "${2}" ] ; then
		return 1
	fi

	# Loop over each file ending in the first argument
	for zzFILE in *"${1}" ; do
		# Rename the file to...
		#   ...the same name but with the ending chopped off...
		#   ...and the new ending (the second argument) added on.
		mv "${zzFILE}" "${zzFILE%${1}}${2}"
	done

	return 0
}
