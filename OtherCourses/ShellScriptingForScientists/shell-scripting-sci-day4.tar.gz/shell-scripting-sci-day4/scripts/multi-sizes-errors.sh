#!/bin/bash
set -e

function check_args()
{
# This function checks all the arguments it has been given

	# Loop through all the arguments we've been given,
	#   checking each in turn.
	for zzARGS in "${@}" ; do

		# Make sure population size is positive
		if [ "${zzARGS}" -lt "1" ] ; then
			echo "Size of population (${zzARGS}) must be positive!" >&2
			exit 1
		fi

		# Make sure population is not too large
		if [ "${zzARGS}" -gt "1000000" ] ; then
			echo "Population (${zzARGS}) too large!" >&2
			exit 1
		fi

	done

	return 0
}

function multi_sizes()
{
# Instead of using read in value for size,
#  cycle through arguments passed to function.

	for zzSIZE in "${@}" ; do

		# Assume parameter set will work
		myBAD_PARAM="0"
		
		# Run program
		run_program "${myZD}" "${myI}" "${myR}" "${myD}" "${zzSIZE}"

		# Report if there were problems
		if [ "${myBAD_PARAM}" -eq "0" ] ; then
			true
		elif [ "${myBAD_PARAM}" -eq "1" ] ; then
			echo "${myPROG} had a problem with parameter set: ${myZD} ${myI} ${myR} ${myD} ${zzSIZE}" >&2
		elif [ "${myBAD_PARAM}" -eq "2" ] ; then
			echo "gnuplot had a problem with parameter set: ${myZD} ${myI} ${myR} ${myD} ${zzSIZE}" >&2
		else
			echo "Problem with parameter set: ${myZD} ${myI} ${myR} ${myD} ${zzSIZE}" >&2
		fi

	done

	return 0
}


function run_program()
{
# This function runs the zombie.py program
#  It sets myBAD_PARAM to 1 if the zombie.py program failed.
#  It sets myBAD_PARAM to 2 if gnuplot failed.

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "" >> "${myLOGFILE}"
	date >> "${myLOGFILE}"
	echo "Running ${myPROG} with ${@}" >> "${myLOGFILE}"

	# Run program with passed arguments
	set +e
	"${myPROG}" "${@}" > "stdout-${1}-${2}-${3}-${4}-${5}"
	myPROG_ERR="${?}"
	set -e

	# Run gnuplot only if the program succeeded
	if [ "${myPROG_ERR}" -eq "0" ] ; then
		set +e
		gnuplot "${myGPLT_FILE}"
		myGPLT_ERR="${?}"
		set -e
	else
		rm -f running-zombie
		echo "Failed!  Exit status: ${myPROG_ERR}" >> "${myLOGFILE}"
		# Set myBAD_PARAM to 1 if the program specified by myPROG failed
		myBAD_PARAM="1"
		return 0
	fi		

	# If gnuplot fails rename zombie.dat file and quit function
	if [ "${myGPLT_ERR}" -ne "0" ] ; then
		echo "gnuplot failed!  Exit status: ${myGPLT_ERR}" >> "${myLOGFILE}"
		mv zombie.dat "zombie-${1}-${2}-${3}-${4}-${5}.dat"
		rm -f running-zombie
		echo "Output file: zombie-${1}-${2}-${3}-${4}-${5}.dat" >> "${myLOGFILE}"
		# Set myBAD_PARAM to 2 if gnuplot failed
		myBAD_PARAM="2"
		return 0
	fi

	# Rename files
	mv zombie.dat "zombie-${1}-${2}-${3}-${4}-${5}.dat"
	mv zombie.png "zombie-${1}-${2}-${3}-${4}-${5}.png"

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "Output file: zombie-${1}-${2}-${3}-${4}-${5}.dat" >> "${myLOGFILE}"
	echo "Plot of output file: zombie-${1}-${2}-${3}-${4}-${5}.png" >> "${myLOGFILE}"
	echo "Standard output: stdout-${1}-${2}-${3}-${4}-${5}" >> "${myLOGFILE}"

	return 0
}

# Program to run: zombie.py
myPROG="$(pwd -P)/zombie.py"

# Set up environment variables for program
export ZOMBIE_FORMAT="NORMAL"

# Location of gnuplot file
myGPLT_FILE="$(pwd -P)/zombie.gplt"

# My current directory
myDIR="$(pwd -P)"

# Location of log file
myLOGFILE="${myDIR}/logfile"

# Make sure our command line arguments are okay before continuing
check_args "${@}"

# Temporary directory for me to work in
myTEMP_DIR="$(mktemp -t -d zombie.XXXXXXXXX)"

# Change to temporary directory
cd "${myTEMP_DIR}"

# Read in parameters from standard input
#   and then run program with them
#   and run it again and again until there are no more
while read myZD myI myR myD mySIZE myJUNK ; do

	if [ -z "${1}" ] ; then
		# If no command line arguments,
		#  use these defaults.
		echo "Using default population sizes: 50, 500, 5000"
		multi_sizes "50" "500" "5000"
	else
		# Use the command line arguments
		multi_sizes "${@}"
	fi

done

# Copy files back to my directory
cp -fpR . "${myDIR}"

# Go back to my directory
cd "${myDIR}"

# Clean up
rm -Rf "${myTEMP_DIR}"
