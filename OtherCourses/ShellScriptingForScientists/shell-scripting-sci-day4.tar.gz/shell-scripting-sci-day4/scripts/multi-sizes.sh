#!/bin/bash
set -e

function check_args()
{
# This function checks all the arguments it has been given

	# Make sure our first argument is not nothing; this also makes sure we are not
	#  given no arguments at all.
	if [ -z "${1}" ] ; then
		echo "Invalid argument or no arguments given." >&2
		echo "This script takes one or more population sizes as its arguments." >&2
		echo "It requires at least one argument." >&2
		exit 1
	fi

	# Loop through all the arguments we've been given,
	#   checking each in turn.
	for zzARGS in "${@}" ; do

		# Make sure population size is positive
		if [ "${zzARGS}" -lt "1" ] ; then
			echo "Size of population (${zzARGS}) must be positive!" >&2
			exit 1
		fi

		# Make sure population is not too large
		if [ "${zzARGS}" -gt "1000000" ] ; then
			echo "Population (${zzARGS}) too large!" >&2
			exit 1
		fi

	done
}

function run_program()
{
# This function runs the zombie.py program

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "" >> "${myLOGFILE}"
	date >> "${myLOGFILE}"
	echo "Running ${myPROG} with ${@}" >> "${myLOGFILE}"

	# Run program with passed arguments
	"${myPROG}" "${@}" > "stdout-${1}-${2}-${3}-${4}-${5}"

	# Run gnuplot
	gnuplot "${myGPLT_FILE}"

	# Rename files
	mv zombie.dat "zombie-${1}-${2}-${3}-${4}-${5}.dat"
	mv zombie.png "zombie-${1}-${2}-${3}-${4}-${5}.png"

	# Remove left over running-zombie file
	rm -f running-zombie

	# Write to logfile
	echo "Output file: zombie-${1}-${2}-${3}-${4}-${5}.dat" >> "${myLOGFILE}"
	echo "Plot of output file: zombie-${1}-${2}-${3}-${4}-${5}.png" >> "${myLOGFILE}"
	echo "Standard output: stdout-${1}-${2}-${3}-${4}-${5}" >> "${myLOGFILE}"
}

# Program to run: zombie.py
myPROG="$(pwd -P)/zombie.py"

# Set up environment variables for program
export ZOMBIE_FORMAT="NORMAL"

# Location of gnuplot file
myGPLT_FILE="$(pwd -P)/zombie.gplt"

# My current directory
myDIR="$(pwd -P)"

# Location of log file
myLOGFILE="${myDIR}/logfile"

# Make sure our command line arguments are okay before continuing
check_args "${@}"

# Temporary directory for me to work in
myTEMP_DIR="$(mktemp -t -d zombie.XXXXXXXXX)"

# Change to temporary directory
cd "${myTEMP_DIR}"

# Read in parameters from standard input
#   and then run program with them
#   and run it again and again until there are no more
while read myZD myI myR myD mySIZE myJUNK ; do

	# Instead of using read in value for size,
	#  cycle through command line arguments.
	for zzSIZE in "${@}" ; do

		# Run program
		run_program "${myZD}" "${myI}" "${myR}" "${myD}" "${zzSIZE}"

	done

done

# Copy files back to my directory
cp -fpR . "${myDIR}"

# Go back to my directory
cd "${myDIR}"

# Clean up
rm -Rf "${myTEMP_DIR}"
