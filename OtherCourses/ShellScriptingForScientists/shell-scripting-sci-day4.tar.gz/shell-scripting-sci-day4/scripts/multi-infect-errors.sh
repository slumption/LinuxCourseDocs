#!/bin/bash
set -e

function run_program()
{
# This function runs the infect.py program
#  It sets myBAD_PARAM to 1 if the infect.py program failed.
#  It sets myBAD_PARAM to 2 if gnuplot failed.

	# Write to logfile
	echo "" >> "${myLOGFILE}"
	date >> "${myLOGFILE}"
	echo "Running ${myPROG} with ${@}" >> "${myLOGFILE}"

	# Run program with passed arguments
	set +e
	"${myPROG}" "${@}" >infect.dat 2>"info-${1}-${2}-${3}-${4}"
	myPROG_ERR="${?}"
	set -e

	# Run gnuplot only if the program succeeded
	if [ "${myPROG_ERR}" -eq "0" ] ; then
		set +e
		gnuplot "${myGPLT_FILE}"
		myGPLT_ERR="${?}"
		set -e
	else
		if [ -e infect.dat ] ; then
			mv infect.dat "infect-${1}-${2}-${3}-${4}.dat"
		fi
		echo "Failed!  Exit status: ${myPROG_ERR}" >> "${myLOGFILE}"
		# Set myBAD_PARAM to 1 if the program specified by myPROG failed
		myBAD_PARAM="1"
		return 0
	fi		

	# If gnuplot fails rename infect.dat file and quit function
	if [ "${myGPLT_ERR}" -ne "0" ] ; then
		echo "gnuplot failed!  Exit status: ${myGPLT_ERR}" >> "${myLOGFILE}"
		mv infect.dat "infect-${1}-${2}-${3}-${4}.dat"
		echo "Output: infect-${1}-${2}-${3}-${4}.dat" >> "${myLOGFILE}"
		echo "Parameter information: info-${1}-${2}-${3}-${4}" >> "${myLOGFILE}"
		# Set myBAD_PARAM to 2 if gnuplot failed
		myBAD_PARAM="2"
		return 0
	fi

	# Rename files
	mv infect.dat "infect-${1}-${2}-${3}-${4}.dat"
	mv infect.png "infect-${1}-${2}-${3}-${4}.png"

	# Write to logfile
	echo "Output: infect-${1}-${2}-${3}-${4}.dat" >> "${myLOGFILE}"
	echo "Plot of output: infect-${1}-${2}-${3}-${4}.png" >> "${myLOGFILE}"
	echo "Parameter information: info-${1}-${2}-${3}-${4}" >> "${myLOGFILE}"

	return 0
}

# Program to run: infect.py
myPROG="$(pwd -P)/infect.py"

# Set up environment variables for program
export INFECT_FORMAT="NORMAL"

# Location of gnuplot file
myGPLT_FILE="$(pwd -P)/infect.gplt"

# My current directory
myDIR="$(pwd -P)"

# Location of log file
myLOGFILE="${myDIR}/logfile"

# Make sure our command line arguments are okay before continuing
if [ -z "${1}" ] ; then
	echo "Invalid argument or no arguments given." >&2
	echo "This script takes one or more population sizes as its arguments." >&2
	echo "It requires at least one argument." >&2
	exit 1
fi

# Temporary directory for me to work in
myTEMP_DIR="$(mktemp -t -d infect.XXXXXXXXX)"

# Change to temporary directory
cd "${myTEMP_DIR}"

# Read in parameters from standard input
#   and then run program with them
#   and run it again and again until there are no more
while read myI myR myB mySIZE myJUNK ; do

	# Instead of using read in value for b,
	#  cycle through command line arguments.
	for zzSIZE in "${@}" ; do

		# Assume parameter set will work
		myBAD_PARAM="0"
		
		# Run program
		run_program "${myI}" "${myR}" "{myB}" "${zzSIZE}"

		# Report if there were problems
		if [ "${myBAD_PARAM}" -eq "0" ] ; then
			true
		elif [ "${myBAD_PARAM}" -eq "1" ] ; then
			echo "${myPROG} had a problem with parameter set: ${myI} ${myR} ${myB} ${zzSIZE}" >&2
		elif [ "${myBAD_PARAM}" -eq "2" ] ; then
			echo "gnuplot had a problem with parameter set: ${myI} ${myR} ${myB} ${zzSIZE}" >&2
		else
			echo "Problem with parameter set: ${myI} ${myR} ${myB} ${zzSIZE}" >&2
		fi

	done

done

# Copy files back to my directory
cp -fpR . "${myDIR}"

# Go back to my directory
cd "${myDIR}"

# Clean up
rm -Rf "${myTEMP_DIR}"
