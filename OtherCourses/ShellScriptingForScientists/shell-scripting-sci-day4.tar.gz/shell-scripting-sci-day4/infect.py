#!/usr/bin/python

####################################################################
###    This is based on a PYTHON version of program 6.4 from       #
### page 203 of the book                                           #
### "Modeling Infectious Disease in humans and animals"            #
### by Keeling & Rohani.					   #
###								   #
### It is the SIR model (including births and deaths) with full    #
### (event-driven) demographic stochasticity.			   #
###								   #
### This is a more complex stochastic model as 6 events are	   #
### possible: infection, recovery, birth, death of susceptible,    #
### death of infected, death of recovered.			   #
### Note: by default we are using a very small population size 	   #
### to highlight the stochasticity.				   #
###                                                                #
### Portions of program copyright (C) <2008> Ilias Soumpasis       #
### ilias.soumpasis@deductivethinking.com                          #
### ilias.soumpasis@gmail.com	                                   #
####################################################################

##########################################################################
### This program is free software: you can redistribute it and/or modify #
### it under the terms of the GNU General Public License as published by #
### the Free Software Foundation, version 3.                             #
###                                                                      #
### This program is distributed in the hope that it will be useful,      #
### but WITHOUT ANY WARRANTY; without even the implied warranty of       #
### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
### GNU General Public License for more details.                         #
###                                                                      #
### You should find a copy of the GNU General Public License at          #
### the Copyrights section or, see http://www.gnu.org/licenses.          #
##########################################################################

import sys, os
import os.path
import time
import math, random

def stoc_eqs(INP,ts): 
	V = list(INP)
	Rate=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
	Change=[[0.0, 0.0, 0.0],
	        [0.0, 0.0, 0.0],
	        [0.0, 0.0, 0.0],
	        [0.0, 0.0, 0.0],
	        [0.0, 0.0, 0.0],
	        [0.0, 0.0, 0.0]]
	N=float(sum(V[0:3]))
	Rate[0] = beta*V[0]*V[1]/N; Change[0]=[-1, +1, 0];
	Rate[1] = gamma*V[1];  Change[1]=[0, -1, +1];
	Rate[2] = mu*N;  Change[2]=[+1, 0, 0];
	Rate[3] = mu*V[0];  Change[3]=[-1, 0, 0];
	Rate[4] = mu*V[1];  Change[4]=[0, -1, 0];
	Rate[5] = mu*V[2];  Change[5]=[0, 0, -1];
	R1=random.random();
	R2=random.random();

	ts = -math.log(R2)/(sum(Rate));

	# Create list of cumulative sums of Rate
	# Equivalent to NumPy's cumsum() function
	cumsum = []
	for i in range(0,len(Rate)):
		cumsum.append(sum(Rate[:i+1]))       
	del i

        # Find indices of cumsum where it is >= R1 * sum of Rate
	# Equivalent to using the matplotib.mlab.find() function as
        #  follows:
	#    matplotib.mlab.find(numpy.cumsum(Rate)>=R1*numpy.sum(Rate))
	find = []
	for i in range(0,len(Rate)):
		if cumsum[i]>=R1*sum(Rate):
			find.append(i)
	del i
	# Take smallest index
	m=min(find)

	del cumsum, find

	for i in range(0,3):
		V[i]=V[i]+Change[m][i]

	del i

	return [V,ts]


def Stoch_Iteration(INPUT):
	lop=0
	ts=0
	T=[0]
	S=[INPUT[0]]
	I=[INPUT[1]]
	R=[INPUT[2]]
	while T[lop] < ND:
		lop=lop+1
		T.append(T[lop-1]+ts)
		S.append(INPUT[0])
		I.append(INPUT[1])
		R.append(INPUT[2])
		[INPUT,ts] = stoc_eqs(INPUT,ts)
		lop=lop+1
		T.append(T[lop-1])
		S.append(INPUT[0])
		I.append(INPUT[1])
		R.append(INPUT[2])
	return [T,S,I,R]




if (len(sys.argv) < 5):
	sys.stderr.write('Wrong number of arguments!\n')
	sys.stderr.write('4 required, %d found.\n' % (len(sys.argv)-1))
	sys.stderr.write('Usage: %s infect recovery birth size\n' % str(sys.argv[0]))
	sys.exit(1)

#For reference: some sensible values
#beta=1.0
#gamma=1/10.0
#mu=5e-4
#N0=5000.0
### You may want to try with population size of 50 (small) to see the events
### In this case uncomment the next line
#N0=50.0
#ND=2*365.0
#Y0=math.ceil(mu*N0/gamma)
#X0=math.floor(gamma*N0/beta)

beta = float(sys.argv[1])
if beta <= 0.0:
	sys.stderr.write('infect (beta) must be positive\n')
	sys.exit(1)

gamma = float(sys.argv[2])
if gamma <= 0.0:
	sys.stderr.write('recovery (gamma) must be positive\n')
	sys.exit(1)

mu = float(sys.argv[3])
if mu <= 0.0:
	sys.stderr.write('birth (mu) must be positive\n')
	sys.exit(1)

N0 = long(sys.argv[4])
if N0 <= 0L:
	sys.stderr.write('size must be positive\n')
	sys.exit(1)

if len(sys.argv) >= 6:
	ND=float(sys.argv[5])*365.0
	if ND <= 0.0:
		sys.stderr.write('time must be positive\n')
		sys.exit(1)
else:
	ND=2*365.0

if len(sys.argv) >= 7:
	X0=long(sys.argv[6])
	if X0 <= 0.0:
		sys.stderr.write('suscept0 (X(0)) must be positive\n')
		sys.exit(1)
else:
	X0=math.floor(gamma*N0/beta)

if len(sys.argv) >= 8:
	Y0=long(sys.argv[7])
	if Y0 <= 0.0:
		sys.stderr.write('infect0 (Y(0)) must be positive\n')
		sys.exit(1)
else:
	Y0=math.ceil(mu*N0/gamma)
	
if (X0 + Y0) >= N0:
	sys.stderr.write('Initial level of suceptible + infected (%d + %d = %d) is greater than population size (%d)\n' % (X0, Y0, X0 + Y0, N0))
	sys.exit(1)

SCI_FMT = True
if 'INFECT_FORMAT' in os.environ:
	if os.environ['INFECT_FORMAT'].upper() == 'NORMAL':
		SCI_FMT = False

RND = False
PRINT_RND_SEED = False
if 'INFECT_RND' in os.environ:
	if os.environ['INFECT_RND'].upper() == 'RANDOM':
		RND = True
	else:
		try:
			RND_SEED = long(os.environ['INFECT_RND'])
		except:
			RND_SEED = 123456L
		PRINT_RND_SEED = True
else:
	RND_SEED = 123456L

Z0=N0-X0-Y0

start = time.time()

INPUT = (X0,Y0,Z0)

[T,S,I,R]=Stoch_Iteration(INPUT)

elapsed = time.time() - start

for i in range(0,len(T)):
	sys.stdout.write('%17f\t%f\t%f\t%f\n' % (T[i]/365.0,S[i],I[i],R[i]))
del i

sys.stderr.write('\nSIR model (including births and deaths) with [event-driven] demographic stochasticity\n\n')

if RND:
	sys.stderr.write('Using randomly chosen seed for pseudo-random number generator\n\n')
	random.seed()
else:
	if PRINT_RND_SEED:
		sys.stderr.write('Using random seed ' + str(RND_SEED) + ' for pseudo-random number generator\n\n')
	random.seed(RND_SEED)

if SCI_FMT:
	sys.stderr.write('Population size:\t%.4e\n' % N0)
	sys.stderr.write('Model run time:\t\t%.1e years\n' % (ND/365.0))
	sys.stderr.write('\nInitial number of susceptible individuals:\t%.3e\n' % X0)
	sys.stderr.write('Initial number of infected individuals:\t\t%.3e\n' % Y0)
	sys.stderr.write('\nTransmission rate (beta):\t\t%e\n' % beta)
	sys.stderr.write('Recovery rate (gamma):\t\t\t%e\n' % gamma)
	sys.stderr.write('Per capita birth [and death] rate (mu):\t%e\n' % mu)
	sys.stderr.write('\nModel took %e seconds\n' % elapsed)
else:
	sys.stderr.write('Population size:\t%d\n' % N0)
	sys.stderr.write('Model run time:\t\t%.1f years\n' % (ND/365.0))
	sys.stderr.write('\nInitial number of susceptible individuals:\t%d\n' % X0)
	sys.stderr.write('Initial number of infected individuals:\t\t%d\n' % Y0)
	sys.stderr.write('\nTransmission rate (beta):\t\t%.4f\n' % beta)
	sys.stderr.write('Recovery rate (gamma):\t\t\t%.4f\n' % gamma)
	sys.stderr.write('Per capita birth [and death] rate (mu):\t%.4f\n' % mu)
	sys.stderr.write('\nModel took %.3f seconds\n' % elapsed)
