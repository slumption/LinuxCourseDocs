#!/bin/bash

# Run gnuplot program once for each output file
for zzFILES in zombie-*.dat ; do

	# Create symbolic link called zombie.dat to output file
	ln -s -f "${zzFILES}" zombie.dat

	# Run gnuplot
	gnuplot zombie.gplt

	# Delete zombie.dat file
	rm -f zombie.dat

	# Rename zombie.png to name that doesn't have .dat in it
	mv zombie.png "${zzFILES%.dat}.png"
done
