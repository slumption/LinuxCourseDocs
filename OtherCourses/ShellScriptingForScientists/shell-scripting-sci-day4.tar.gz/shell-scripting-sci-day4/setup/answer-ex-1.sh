#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/first-exercise.sh scripts/multi-variable-params.sh

echo "The answer to the first exercise is in the script:"
echo "        multi-variable-params.sh"
echo "in:"
echo "        $(pwd -P)/scripts"
exit 0
