#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers//multi-variable-params.sh scripts

echo "The answer to the third exercise is in the script:"
echo "        multi-variable-params.sh"
echo "in:"
echo "        $(pwd -P)/scripts"
exit 0
