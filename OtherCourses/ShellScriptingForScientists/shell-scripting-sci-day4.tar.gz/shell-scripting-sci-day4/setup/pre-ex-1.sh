#!/bin/bash
# None of this is actually *needed* for the
#  first exercise, so we run with set +e
set +e

# All paths are relative to the HOME directory
cd

echo "Ready for first exercise."
exit 0
