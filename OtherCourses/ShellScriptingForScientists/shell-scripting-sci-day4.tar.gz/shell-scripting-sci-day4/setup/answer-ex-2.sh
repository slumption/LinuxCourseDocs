#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/my-functions.sh scripts
cp -pf answers/second-exercise.sh scripts/multi-variable-params.sh

echo "The answer to the second exercise is in the scripts:"
echo "        my-functions.sh"
echo "        multi-variable-params.sh"
echo "in:"
echo "        $(pwd -P)/scripts"
exit 0
