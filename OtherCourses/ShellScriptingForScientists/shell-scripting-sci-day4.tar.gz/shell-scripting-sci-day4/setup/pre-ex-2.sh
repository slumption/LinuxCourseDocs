#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/first-exercise.sh scripts/multi-variable-params.sh

echo "Ready for second exercise."
exit 0
