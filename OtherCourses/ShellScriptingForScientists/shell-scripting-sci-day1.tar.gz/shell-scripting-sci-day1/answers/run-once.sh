#!/bin/bash

# Remove left over running-zombie file
rm -f running-zombie

# Write to logfile
echo "" >> logfile
date >> logfile
echo "Running zombie.py with ${@}" >> logfile

# Run zombie.py with passed arguments
ZOMBIE_FORMAT="NORMAL" ./zombie.py "${@}" > "stdout-${5}"

# Rename output file
mv zombie.dat "zombie-${5}.dat"

# Remove left over running-zombie file
rm -f running-zombie

# Write to logfile
echo "Output file: zombie-${5}.dat" >> logfile
echo "Standard output: stdout-${5}" >> logfile
