#!/bin/bash
echo "Changing to home directory..."
cd
echo "Deleting the play directory..."
rm -Rf play
echo "Making a play subdirectory..."
mkdir play
echo "Copying the examples subdirectory to play..."
cp -pR examples/. play
echo "Printing out the date and time..."
date
