#!/bin/bash

# Remove left over running-zombie file
rm -f running-zombie

# Run zombie.py with passed arguments
ZOMBIE_FORMAT="NORMAL" ./zombie.py "${@}"

# Rename output file
mv zombie.dat "zombie-${5}.dat"

# Remove left over running-zombie file
rm -f running-zombie
