#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/run-once.sh scripts

echo "Ready for the final exercise."
