#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

if [ ! -e run-zombie.sh ] ; then
	cp -p answers/second-exercise.sh run-zombie.sh
	echo "The answer to the second exercise is in the script:"
	echo "        run-zombie.sh"
	echo "in:"
	echo "        $(pwd -P)"
else
	echo "The answer to the second exercise is in the script:"
	echo "        second-exercise.sh"
	echo "in:"
	echo "        $(pwd -P)/answers"
fi
