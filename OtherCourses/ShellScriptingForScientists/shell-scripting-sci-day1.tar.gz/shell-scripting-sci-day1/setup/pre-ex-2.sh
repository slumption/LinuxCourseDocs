#!/bin/bash
# None of this is actually *needed* for the 
#  second exercise, so we run with set +e
set +e

# All paths are relative to the HOME directory
cd

cp -pf setup/cleanup-prog-dir.sh source

echo "Ready for second exercise."
exit 0

