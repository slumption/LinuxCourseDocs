#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

if [ ! -d examples ]; then
	echo "Missing examples directory - you won't be able to do the first exercise!" >&2
	exit 1
else
	echo "Ready for the first exercise."
	exit 0
fi
