#!/bin/bash
set -e

# All paths are relative to the HOME directory
cd

cp -pf answers/setup-play.sh .

# We don't mind if this copy doesn't succeed, so
#  we switch to running with set +e
set +e
cp -pf answers/setup-play.sh bin

echo "The answer to the first exercise is in the script:"
echo "        setup-play.sh"
echo "in:"
echo "        $(pwd -P)"
exit 0
