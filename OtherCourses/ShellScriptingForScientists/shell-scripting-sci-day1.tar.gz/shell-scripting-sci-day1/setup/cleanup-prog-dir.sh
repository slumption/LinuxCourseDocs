#!/bin/bash

# Change to my home directory
#  as directories are relative to home
cd

# Make backup directory
mkdir -p backup

# Move editor backups to backup directory
mv source/*~ backup
mv source/*.bak backup

# Delete compiler object files
rm -f source/*.o
