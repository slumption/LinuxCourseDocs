#!/bin/bash

cd

mkdir backup

mv source/*~ backup
mv source/*.bak backup

rm source/*.o
