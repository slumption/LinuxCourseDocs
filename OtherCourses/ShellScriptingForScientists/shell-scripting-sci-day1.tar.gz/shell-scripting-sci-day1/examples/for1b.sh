#!/bin/bash
set -e

# Examples of for loop

for zzVAR in "${@}" ; do

	echo "${zzVAR}"

done

echo "End."
