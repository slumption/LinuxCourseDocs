#!/bin/bash
set -e

# Examples of using shell parameters

echo "This script is ${0}"

echo ""

echo "There are ${#} command line arguments."

echo ""

echo "The first command line argument is: ${1}"
echo "The second command line argument is: ${2}"
echo "The third command line argument is: ${3}"

echo ""

echo "Command line passed to this script: ${@}"
